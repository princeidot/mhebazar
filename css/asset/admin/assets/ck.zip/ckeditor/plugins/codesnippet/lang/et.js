﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","et",{button:"Koodijupi sisestamine",codeContents:"Koodi sisu",emptySnippetError:"Koodijupp ei saa olla tühi.",language:"Keel",title:"Koodijupp",pathName:"koodijupp"});